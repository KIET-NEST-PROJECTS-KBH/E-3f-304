# Import necessary libraries
import pandas as pd
from flask import Flask, render_template, request, redirect, url_for

# Create a Flask app
app = Flask(__name__)

# Load your dataset and create the Decision Tree Classifier (similar to previous examples)
data = {
    'Account_Number': [101,102, 103, 104, 105,],
    'Credit_Score': [720, 650, 800, 600, 550],
    'Annual_Income': [60000, 50000, 75000, 45000, 40000],
    'Loan_Approval': ['Yes', 'No', 'Yes', 'No', 'No']
}
df = pd.DataFrame(data)

# Define your features (X) excluding the account number
X = df[['Credit_Score', 'Annual_Income']]
y = df['Loan_Approval']

from sklearn.tree import DecisionTreeClassifier
clf = DecisionTreeClassifier()
clf.fit(X, y)

# Define a route to render the HTML form (only for GET requests)
@app.route('/', methods=['GET'])
def index():
    return render_template('login.html', result=None)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        # Handle registration form submission
        # Example: Get data from form using request.form['field_name']
        username = request.form['username']
        password = request.form['password']
        # Perform registration logic (e.g., store data in a database)
        # Redirect to login page or home page after registration
        return redirect(url_for('index'))
    return render_template('register.html')

@app.route('/home', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        # Handle the POST request, if needed
        pass
    return render_template('home.html', result=None)




# Define a route to handle the form submission and redirect to the result page (only for POST requests)
@app.route('/index', methods=['GET', 'POST'])
def check_eligibility():
    if request.method == 'POST':
        # Get the account number entered by the user
        user_account_number = int(request.form['account_number'])
        
        # Retrieve the data for the specific user based on the provided account number
        user_data = df[df['Account_Number'] == user_account_number]
        if not user_data.empty:
            # Extract the features for prediction
            user_features = user_data[['Credit_Score', 'Annual_Income']]
            
            # Make a prediction for the user based on the provided features
            prediction = clf.predict(user_features)
            
            # Check if the prediction is 'Yes' for eligibility
            if prediction[0] == 'Yes':
                # Redirect to the 'care.html' page for eligible users
                return redirect(url_for('display_result', result='eligible'))
            else:
                # Display "Not eligible" for non-eligible users
                return "Not eligible"
        else:
            # Handle the case where the user account number is not found
            return "Invalid account number."
    
    # Handle GET request (e.g., rendering the form)
    return render_template('index.html')

# Define a route to display the result
@app.route('/display_result')
def display_result():
    result = request.args.get('result', default=None)  # Get the result from the URL parameter
    
    if result == 'eligible':
        return render_template('care.html')  # Redirect to 'care.html' for eligible users
    
    return result  # Return "Not eligible" as plain text for non-eligible users or "Invalid account number."


@app.route('/end', methods=['GET', 'POST'])
def end():
    if request.method == 'POST':
        # Handle the POST request, if needed
        pass
    return render_template('end.html', result=None)



if __name__ == '__main__':
    app.run(debug=True)

